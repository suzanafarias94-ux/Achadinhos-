# Achadinhos — versão inicial independente

Ferramenta mobile-first: cola o link, consulta o produto no servidor e gera mensagem pronta para copiar/compartilhar.

## Rodar localmente

1. Instale Node.js 20 ou superior.
2. Copie `.env.example` para `.env` e configure as variáveis da Amazon (e, se necessário, Mercado Livre).
3. Execute `npm start` nesta pasta.
4. Abra `http://localhost:3000`.

O servidor usa apenas módulos nativos do Node.js.

## Integrações nesta versão

- **Mercado Livre:** consulta o anúncio pela API pública de itens; aceita links de catálogo que contenham o ID MLB do anúncio.
- **Amazon:** usa a Creators API oficial. É necessário configurar `AMAZON_CLIENT_ID`, `AMAZON_CLIENT_SECRET`, `AMAZON_CREDENTIAL_VERSION` e `AMAZON_PARTNER_TAG` no servidor. As credenciais nunca vão para o navegador.
- **Shopee e SHEIN:** tenta ler os metadados públicos da página (Open Graph/Twitter Cards). Essas lojas podem bloquear a consulta automatizada, exigir sessão ou não expor preço/imagem. Nesses casos, o sistema avisa em vez de inventar dados.

## Importante

Este pacote é um projeto executável localmente, não um site já publicado. Para funcionar por um endereço público, é necessário hospedar o servidor Node.js em um serviço compatível e cadastrar as variáveis secretas no painel desse serviço. Não coloque credenciais no HTML, no Git ou em mensagens.

A geração de links de afiliado ainda é separada da leitura. A Amazon usa a URL retornada pela Creators API. Mercado Livre, Shopee e SHEIN permanecem com o link original nesta primeira versão; a conversão/encurtamento afiliado depende das integrações e permissões específicas da conta.
